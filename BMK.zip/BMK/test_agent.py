#!/usr/bin/env python3
"""
Intelligent Agent for Smart Home Automation - Automated Logic Test Suite (Python)
Validates all decision rules, priority hierarchies, and edge cases.
"""

import unittest

class SmartHomeAgentPython:
    def __init__(self):
        self.temperature = 24.0
        self.occupancy = True
        self.ambient_light = 60.0
        self.smoke = False

        self.cooling = False
        self.cooling_state = "OFF"
        self.lights = False
        self.lights_state = "OFF"
        self.energy_saving = False
        self.emergency_warning = False
        self.alarm_audible = False
        self.browser_notification = False

        self.active_rule_id = "RULE_STANDBY"
        self.priority_level = 4
        self.reasoning = ""

        self.COOLING_TEMP_THRESHOLD = 30.0
        self.LIGHT_THRESHOLD = 35.0

        self.evaluate()

    def update_sensors(self, temperature=None, occupancy=None, ambient_light=None, smoke=None):
        if temperature is not None:
            self.temperature = float(temperature)
        if occupancy is not None:
            self.occupancy = bool(occupancy)
        if ambient_light is not None:
            self.ambient_light = float(ambient_light)
        if smoke is not None:
            self.smoke = bool(smoke)
        return self.evaluate()

    def evaluate(self):
        # Priority 1 (Highest): Smoke Detection
        if self.smoke:
            self.active_rule_id = "RULE_1_SMOKE_EMERGENCY"
            self.priority_level = 1
            self.emergency_warning = True
            self.alarm_audible = True
            self.browser_notification = True

            # Emergency overrides
            self.cooling = False
            self.cooling_state = "EMERGENCY_SHUTDOWN"
            self.lights = True
            self.lights_state = "EMERGENCY_ILLUMINATION"
            self.energy_saving = False
            self.reasoning = "PRIORITY 1: Smoke detected! Emergency siren & notification triggered. HVAC shutdown, emergency lighting ON."
            return self

        # Non-emergency
        self.emergency_warning = False
        self.alarm_audible = False
        self.browser_notification = False

        # Priority 2: Empty Room Energy-Saving Mode
        if not self.occupancy:
            self.active_rule_id = "RULE_2_ENERGY_SAVING"
            self.priority_level = 2
            self.energy_saving = True
            self.cooling = False
            self.cooling_state = "OFF"
            self.lights = False
            self.lights_state = "OFF"
            self.reasoning = "PRIORITY 2: Room is empty. Energy-saving mode active. Cooling and lights forced OFF."
            return self

        # Priority 3 & 4: Occupied Room - Thermal Comfort and Ambient Lighting
        self.energy_saving = False

        # Rule 3: Cooling activation when temp >= 30°C
        if self.temperature >= self.COOLING_TEMP_THRESHOLD:
            self.cooling = True
            self.cooling_state = "ACTIVE"
        else:
            self.cooling = False
            self.cooling_state = "OFF"

        # Rule 4: Lights ON when person is present and light < 35%
        if self.ambient_light < self.LIGHT_THRESHOLD:
            self.lights = True
            self.lights_state = "ACTIVE"
        else:
            self.lights = False
            self.lights_state = "OFF"

        if self.cooling and self.lights:
            self.active_rule_id = "RULE_3_4_COMFORT_COMBO"
            self.priority_level = 3
            self.reasoning = "Room occupied: High temperature (>=30°C) and low light (<35%). Cooling and lights both ON."
        elif self.cooling:
            self.active_rule_id = "RULE_3_COOLING"
            self.priority_level = 3
            self.reasoning = "Room occupied: High temperature (>=30°C). Cooling ON."
        elif self.lights:
            self.active_rule_id = "RULE_4_LIGHTING"
            self.priority_level = 4
            self.reasoning = "Room occupied: Low ambient light (<35%). Lights ON."
        else:
            self.active_rule_id = "RULE_STANDBY"
            self.priority_level = 5
            self.reasoning = "Room occupied: Optimal conditions. Cooling and lights OFF."

        return self

    def reset(self):
        self.temperature = 24.0
        self.occupancy = True
        self.ambient_light = 60.0
        self.smoke = False
        return self.evaluate()


class TestSmartHomeAgentLogic(unittest.TestCase):
    def setUp(self):
        self.agent = SmartHomeAgentPython()

    def test_tc1_high_temperature_cooling(self):
        """Test Case 1: Temp >= 30°C with occupancy activates cooling"""
        self.agent.update_sensors(temperature=32.0, occupancy=True, ambient_light=50.0, smoke=False)
        self.assertTrue(self.agent.cooling)
        self.assertEqual(self.agent.cooling_state, "ACTIVE")
        self.assertFalse(self.agent.lights)
        self.assertFalse(self.agent.energy_saving)

    def test_tc1_temp_boundary_exact_30(self):
        """Boundary Test: Exactly 30.0°C must activate cooling"""
        self.agent.update_sensors(temperature=30.0, occupancy=True, ambient_light=50.0, smoke=False)
        self.assertTrue(self.agent.cooling)

    def test_tc1_temp_below_threshold(self):
        """Negative Test: Temp < 30.0°C (e.g. 29.9°C) keeps cooling OFF"""
        self.agent.update_sensors(temperature=29.9, occupancy=True, ambient_light=50.0, smoke=False)
        self.assertFalse(self.agent.cooling)

    def test_tc2_dark_room_lighting(self):
        """Test Case 2: Light < 35% with occupancy turns lights ON"""
        self.agent.update_sensors(temperature=24.0, occupancy=True, ambient_light=25.0, smoke=False)
        self.assertTrue(self.agent.lights)
        self.assertEqual(self.agent.lights_state, "ACTIVE")
        self.assertFalse(self.agent.cooling)
        self.assertFalse(self.agent.energy_saving)

    def test_tc2_light_boundary_35(self):
        """Boundary Test: Ambient light at 35.0% keeps lights OFF"""
        self.agent.update_sensors(temperature=24.0, occupancy=True, ambient_light=35.0, smoke=False)
        self.assertFalse(self.agent.lights)

    def test_tc3_combo_high_temp_and_dark(self):
        """Test Case 3: Temp >= 30°C AND light < 35% turns both Cooling and Lights ON"""
        self.agent.update_sensors(temperature=34.0, occupancy=True, ambient_light=15.0, smoke=False)
        self.assertTrue(self.agent.cooling)
        self.assertTrue(self.agent.lights)
        self.assertFalse(self.agent.energy_saving)

    def test_tc4_empty_room_energy_saving(self):
        """Test Case 4: Vacant room activates Energy-Saving mode and turns lights & cooling OFF"""
        self.agent.update_sensors(temperature=36.0, occupancy=False, ambient_light=10.0, smoke=False)
        self.assertTrue(self.agent.energy_saving)
        self.assertFalse(self.agent.cooling)
        self.assertFalse(self.agent.lights)
        self.assertEqual(self.agent.priority_level, 2)

    def test_tc5_smoke_emergency_highest_priority(self):
        """Test Case 5: Smoke detection triggers emergency warning, siren, notification and overrides all rules"""
        # Even if room is empty and temp is hot
        self.agent.update_sensors(temperature=35.0, occupancy=False, ambient_light=10.0, smoke=True)
        self.assertTrue(self.agent.emergency_warning)
        self.assertTrue(self.agent.alarm_audible)
        self.assertTrue(self.agent.browser_notification)
        self.assertEqual(self.agent.priority_level, 1)
        self.assertFalse(self.agent.energy_saving, "Energy saving must be overridden by emergency")
        self.assertFalse(self.agent.cooling, "Cooling must be safely shutdown during fire emergency")
        self.assertTrue(self.agent.lights, "Emergency evacuation lights must be illuminated")

    def test_reset_behavior(self):
        """Verify system reset restores baseline safe conditions"""
        self.agent.update_sensors(temperature=40.0, occupancy=False, ambient_light=5.0, smoke=True)
        self.agent.reset()
        self.assertEqual(self.agent.temperature, 24.0)
        self.assertTrue(self.agent.occupancy)
        self.assertEqual(self.agent.ambient_light, 60.0)
        self.assertFalse(self.agent.smoke)
        self.assertFalse(self.agent.emergency_warning)
        self.assertFalse(self.agent.cooling)
        self.assertFalse(self.agent.lights)
        self.assertFalse(self.agent.energy_saving)


if __name__ == '__main__':
    print("=" * 70)
    print("SMART HOME AUTOMATION - AGENT DECISION LOGIC TEST SUITE")
    print("=" * 70)
    unittest.main(verbosity=2)
