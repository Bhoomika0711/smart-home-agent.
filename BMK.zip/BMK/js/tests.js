/**
 * Automated Unit Test Suite for Intelligent Agent Decision Logic
 * Validates all assignment rules, edge cases, priority hierarchies, and overrides.
 */

class AgentTestSuite {
  constructor() {
    this.results = [];
    this.isRunning = false;
  }

  assert(condition, message) {
    if (!condition) {
      throw new Error(`Assertion failed: ${message}`);
    }
  }

  assertEqual(actual, expected, message) {
    if (actual !== expected) {
      throw new Error(`${message} -> Expected [${expected}], but received [${actual}]`);
    }
  }

  /**
   * Run all automated test cases
   * @returns {Object} test execution summary
   */
  async runAllTests() {
    this.results = [];
    this.isRunning = true;
    const startTime = performance.now();

    const testDefinitions = [
      {
        id: 'TC-01',
        title: 'Thermal Rule: Temperature >= 30°C activates cooling when occupied',
        testFn: () => {
          const agent = new SmartHomeAgent();
          agent.updateSensors({ temperature: 32.5, occupancy: true, ambientLight: 50, smoke: false });
          this.assertEqual(agent.actuators.cooling, true, 'Cooling system must be ON');
          this.assertEqual(agent.actuators.coolingState, 'ACTIVE', 'Cooling state must be ACTIVE');
          this.assertEqual(agent.actuators.energySaving, false, 'Energy saving must be INACTIVE');
        }
      },
      {
        id: 'TC-02',
        title: 'Thermal Rule: Temperature < 30°C keeps cooling OFF when occupied',
        testFn: () => {
          const agent = new SmartHomeAgent();
          agent.updateSensors({ temperature: 29.5, occupancy: true, ambientLight: 50, smoke: false });
          this.assertEqual(agent.actuators.cooling, false, 'Cooling system must be OFF below 30°C');
          this.assertEqual(agent.actuators.coolingState, 'OFF', 'Cooling state must be OFF');
        }
      },
      {
        id: 'TC-03',
        title: 'Thermal Boundary: Temperature at exactly 30.0°C activates cooling',
        testFn: () => {
          const agent = new SmartHomeAgent();
          agent.updateSensors({ temperature: 30.0, occupancy: true, ambientLight: 50, smoke: false });
          this.assertEqual(agent.actuators.cooling, true, 'Boundary 30.0°C must trigger Cooling ON');
        }
      },
      {
        id: 'TC-04',
        title: 'Lighting Rule: Occupied and ambient light < 35% turns lights ON',
        testFn: () => {
          const agent = new SmartHomeAgent();
          agent.updateSensors({ temperature: 24.0, occupancy: true, ambientLight: 20.0, smoke: false });
          this.assertEqual(agent.actuators.lights, true, 'Smart lights must be ON when light < 35%');
          this.assertEqual(agent.actuators.lightsState, 'ACTIVE', 'Lights state must be ACTIVE');
        }
      },
      {
        id: 'TC-05',
        title: 'Lighting Rule: Occupied and ambient light >= 35% keeps lights OFF',
        testFn: () => {
          const agent = new SmartHomeAgent();
          agent.updateSensors({ temperature: 24.0, occupancy: true, ambientLight: 35.0, smoke: false });
          this.assertEqual(agent.actuators.lights, false, 'Smart lights must remain OFF when light >= 35%');
        }
      },
      {
        id: 'TC-06',
        title: 'Lighting Boundary: Ambient light at 34.9% turns lights ON, 35.0% keeps lights OFF',
        testFn: () => {
          const agent = new SmartHomeAgent();
          agent.updateSensors({ occupancy: true, ambientLight: 34.9, smoke: false });
          this.assertEqual(agent.actuators.lights, true, '34.9% must trigger lights ON');
          agent.updateSensors({ ambientLight: 35.0 });
          this.assertEqual(agent.actuators.lights, false, '35.0% must keep lights OFF');
        }
      },
      {
        id: 'TC-07',
        title: 'Energy-Saving Rule: Empty room activates Energy-Saving Mode',
        testFn: () => {
          const agent = new SmartHomeAgent();
          agent.updateSensors({ occupancy: false, smoke: false });
          this.assertEqual(agent.actuators.energySaving, true, 'Energy-saving mode must be ACTIVE');
          this.assertEqual(agent.actuators.lights, false, 'Lights must be OFF');
          this.assertEqual(agent.actuators.cooling, false, 'Cooling must be OFF');
        }
      },
      {
        id: 'TC-08',
        title: 'Energy-Saving Priority: Empty room forces Cooling OFF even when temp >= 30°C',
        testFn: () => {
          const agent = new SmartHomeAgent();
          agent.updateSensors({ occupancy: false, temperature: 38.0, ambientLight: 60, smoke: false });
          this.assertEqual(agent.actuators.cooling, false, 'Cooling must be forced OFF in empty room despite 38°C');
          this.assertEqual(agent.actuators.energySaving, true, 'Energy-saving must remain ACTIVE');
        }
      },
      {
        id: 'TC-09',
        title: 'Energy-Saving Priority: Empty room forces Lights OFF even when light < 35%',
        testFn: () => {
          const agent = new SmartHomeAgent();
          agent.updateSensors({ occupancy: false, ambientLight: 10.0, temperature: 22, smoke: false });
          this.assertEqual(agent.actuators.lights, false, 'Lights must be forced OFF in empty room despite 10% dark');
          this.assertEqual(agent.actuators.energySaving, true, 'Energy-saving must remain ACTIVE');
        }
      },
      {
        id: 'TC-10',
        title: 'Smoke Emergency Rule: Smoke detection triggers emergency warning, siren and notification',
        testFn: () => {
          const agent = new SmartHomeAgent();
          agent.updateSensors({ smoke: true });
          this.assertEqual(agent.actuators.emergencyWarning, true, 'Emergency warning must be ACTIVE');
          this.assertEqual(agent.actuators.alarmAudible, true, 'Repeating audible alarm must be ACTIVE');
          this.assertEqual(agent.actuators.browserNotification, true, 'Browser notification flag must be TRUE');
        }
      },
      {
        id: 'TC-11',
        title: 'Smoke Priority Override: Smoke overrides Empty Room energy saving (Priority 1 > Priority 2)',
        testFn: () => {
          const agent = new SmartHomeAgent();
          agent.updateSensors({ occupancy: false, smoke: true });
          this.assertEqual(agent.actuators.emergencyWarning, true, 'Emergency warning active despite empty room');
          this.assertEqual(agent.actuators.energySaving, false, 'Energy-saving overridden by emergency');
          this.assertEqual(agent.decision.priorityLevel, 1, 'Active priority must be Priority 1');
          this.assertEqual(agent.actuators.lights, true, 'Emergency evacuation lights must be illuminated');
        }
      },
      {
        id: 'TC-12',
        title: 'Smoke Safety HVAC Shutdown: Smoke halts Cooling to prevent smoke propagation through ducts',
        testFn: () => {
          const agent = new SmartHomeAgent();
          agent.updateSensors({ occupancy: true, temperature: 35.0, smoke: true });
          this.assertEqual(agent.actuators.cooling, false, 'Cooling must be SHUTDOWN during smoke emergency');
          this.assertEqual(agent.actuators.coolingState, 'EMERGENCY_SHUTDOWN', 'Cooling state must indicate emergency shutdown');
        }
      },
      {
        id: 'TC-13',
        title: 'Comfort Combination: Occupied + Temp >= 30°C + Light < 35% turns both Cooling and Lights ON',
        testFn: () => {
          const agent = new SmartHomeAgent();
          agent.updateSensors({ occupancy: true, temperature: 33.0, ambientLight: 15.0, smoke: false });
          this.assertEqual(agent.actuators.cooling, true, 'Cooling must be ON');
          this.assertEqual(agent.actuators.lights, true, 'Lights must be ON');
          this.assertEqual(agent.actuators.energySaving, false, 'Energy saving must be INACTIVE');
        }
      },
      {
        id: 'TC-14',
        title: 'Reset Integrity: System baseline reset re-establishes nominal safe states',
        testFn: () => {
          const agent = new SmartHomeAgent();
          agent.updateSensors({ temperature: 38, occupancy: false, ambientLight: 10, smoke: true });
          agent.reset();
          this.assertEqual(agent.sensors.temperature, 24.0, 'Reset temperature must be 24°C');
          this.assertEqual(agent.sensors.occupancy, true, 'Reset occupancy must be TRUE');
          this.assertEqual(agent.sensors.ambientLight, 60.0, 'Reset light must be 60%');
          this.assertEqual(agent.sensors.smoke, false, 'Reset smoke must be FALSE');
          this.assertEqual(agent.actuators.emergencyWarning, false, 'Emergency warning must be cleared');
        }
      },
      {
        id: 'TC-15',
        title: 'Audit Logging: State transitions generate timestamped action log entries',
        testFn: () => {
          const agent = new SmartHomeAgent();
          agent.clearLogs();
          agent.updateSensors({ temperature: 33.0 });
          this.assert(agent.actionLogs.length > 0, 'Log entries must be created on state transition');
          this.assertEqual(agent.actionLogs[0].category, 'COOLING', 'Log category must record COOLING transition');
        }
      }
    ];

    for (const test of testDefinitions) {
      const testStart = performance.now();
      try {
        test.testFn();
        const duration = Math.round(performance.now() - testStart);
        this.results.push({
          id: test.id,
          title: test.title,
          passed: true,
          durationMs: duration,
          error: null
        });
      } catch (err) {
        const duration = Math.round(performance.now() - testStart);
        this.results.push({
          id: test.id,
          title: test.title,
          passed: false,
          durationMs: duration,
          error: err.message
        });
      }
    }

    const totalDuration = Math.round(performance.now() - startTime);
    const passedCount = this.results.filter(r => r.passed).length;
    const failedCount = this.results.length - passedCount;

    this.isRunning = false;

    return {
      total: this.results.length,
      passed: passedCount,
      failed: failedCount,
      passRate: Math.round((passedCount / this.results.length) * 100),
      durationMs: totalDuration,
      tests: this.results
    };
  }
}

// Export for browser and Node
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { AgentTestSuite };
} else {
  window.AgentTestSuite = AgentTestSuite;
}
