/**
 * Intelligent Agent for Smart Home Automation - Core Decision Engine
 * 
 * Rules Architecture & Priority Hierarchy:
 * Priority 1 (Highest): Smoke Detection Emergency Override
 * Priority 2: Empty Room Energy-Saving Mode
 * Priority 3: Automatic Cooling System (Temperature >= 30°C)
 * Priority 4: Automatic Smart Lighting (Occupied AND Ambient Light < 35%)
 */

class SmartHomeAgent {
  constructor() {
    // Sensor Inputs (Simulated)
    this.sensors = {
      temperature: 24.0,   // degrees Celsius (range: 10 - 45°C)
      occupancy: true,      // boolean (true: person present, false: vacant)
      ambientLight: 60.0,   // percentage (0 - 100%)
      smoke: false          // boolean (true: smoke detected, false: normal)
    };

    // Actuator Outputs
    this.actuators = {
      cooling: false,           // boolean (true: ON, false: OFF)
      coolingState: 'OFF',      // 'OFF' | 'ACTIVE' | 'EMERGENCY_SHUTDOWN'
      coolingPowerW: 0,         // Watts
      lights: false,            // boolean (true: ON, false: OFF)
      lightsState: 'OFF',       // 'OFF' | 'ACTIVE' | 'EMERGENCY_ILLUMINATION'
      lightsPowerW: 0,          // Watts
      energySaving: false,      // boolean (true: ACTIVE, false: INACTIVE)
      emergencyWarning: false,  // boolean (true: ACTIVE, false: NORMAL)
      alarmAudible: false,      // boolean (repeating siren sounding)
      browserNotification: false// boolean (notification sent)
    };

    // Agent Decision Reasoning State
    this.decision = {
      activeRuleId: 'RULE_STANDBY',
      activeRuleName: 'Optimal Standby',
      priorityLevel: 0,
      priorityLabel: 'Standby',
      reasoning: 'System in nominal standby. Environmental conditions within comfortable thresholds.',
      triggeredRules: [],
      timestamp: new Date()
    };

    // Action Event History Log
    this.actionLogs = [];

    // Threshold Constants
    this.THRESHOLDS = {
      COOLING_TEMP_C: 30.0,
      LIGHT_PERCENT: 35.0,
      AC_POWER_W: 1600,
      LIGHTS_POWER_W: 65,
      BASE_STANDBY_W: 20,
      ECO_SAVINGS_W: 1500
    };

    // Perform initial evaluation
    this.evaluate();
  }

  /**
   * Update sensor values and run decision evaluation
   * @param {Object} partialSensors 
   * @returns {Object} evaluation results
   */
  updateSensors(partialSensors) {
    const prevSensors = { ...this.sensors };
    let hasChanges = false;

    for (const [key, value] of Object.entries(partialSensors)) {
      if (this.sensors[key] !== undefined && this.sensors[key] !== value) {
        this.sensors[key] = value;
        hasChanges = true;
      }
    }

    if (hasChanges) {
      return this.evaluate(prevSensors);
    }
    return this.getState();
  }

  /**
   * Core Rule-Based Intelligent Agent Inference Cycle
   * Strict priority evaluation with conflict resolution
   */
  evaluate(prevSensors = null) {
    const prevState = {
      cooling: this.actuators.cooling,
      lights: this.actuators.lights,
      energySaving: this.actuators.energySaving,
      emergencyWarning: this.actuators.emergencyWarning,
      alarmAudible: this.actuators.alarmAudible
    };

    const triggeredRules = [];
    let activeRuleId = 'RULE_STANDBY';
    let activeRuleName = 'Nominal Standby';
    let priorityLevel = 4;
    let priorityLabel = 'Nominal';
    let reasoning = '';

    // =========================================================================
    // PRIORITY 1 (HIGHEST): SMOKE SENSOR DETECTION (CRITICAL EMERGENCY)
    // Requirement 9: Immediately trigger emergency warning, repeating audible alarm and browser notification
    // Requirement 10: Smoke detection must have the highest priority, overriding all other rules.
    // =========================================================================
    if (this.sensors.smoke === true) {
      activeRuleId = 'RULE_1_SMOKE_EMERGENCY';
      activeRuleName = 'Smoke Emergency Override';
      priorityLevel = 1;
      priorityLabel = 'CRITICAL (Priority 1)';
      
      // Actuator enforcement for emergency
      this.actuators.emergencyWarning = true;
      this.actuators.alarmAudible = true;
      this.actuators.browserNotification = true;
      
      // Safety overrides:
      // In fire/smoke emergency, HVAC cooling MUST be shutdown to avoid circulating smoke/air through ducts.
      this.actuators.cooling = false;
      this.actuators.coolingState = 'EMERGENCY_SHUTDOWN';
      this.actuators.coolingPowerW = 0;
      
      // Emergency lighting is activated to illuminate safe evacuation routes regardless of occupancy/ambient light.
      this.actuators.lights = true;
      this.actuators.lightsState = 'EMERGENCY_ILLUMINATION';
      this.actuators.lightsPowerW = this.THRESHOLDS.LIGHTS_POWER_W;
      
      // Energy saving mode is completely overridden by life safety
      this.actuators.energySaving = false;

      reasoning = 'CRITICAL ALERT: Smoke detected by safety sensor. PRIORITY 1 OVERRIDE ACTIVE. ' +
        'Immediate repeating audible alarm sounding and browser notification dispatched. ' +
        'HVAC cooling safely shutdown to halt smoke ventilation; emergency illumination activated.';

      triggeredRules.push({
        id: 'RULE_1',
        name: 'Smoke Emergency Hazard Response',
        priority: 1,
        status: 'FIRED_ACTIVE',
        details: 'Hazard detected: smoke=TRUE overrides all environmental comfort and energy rules.'
      });

    } else {
      // Normal non-emergency operations: clear emergency warnings
      this.actuators.emergencyWarning = false;
      this.actuators.alarmAudible = false;
      this.actuators.browserNotification = false;

      // =======================================================================
      // PRIORITY 2: EMPTY ROOM / OCCUPANCY SENSOR (ENERGY-SAVING MODE)
      // Requirement 8: When the room is empty, activate energy-saving mode and turn lights and cooling OFF.
      // =======================================================================
      if (this.sensors.occupancy === false) {
        activeRuleId = 'RULE_2_ENERGY_SAVING';
        activeRuleName = 'Empty Room Energy-Saving Mode';
        priorityLevel = 2;
        priorityLabel = 'High (Priority 2)';

        this.actuators.energySaving = true;
        this.actuators.cooling = false;
        this.actuators.coolingState = 'OFF';
        this.actuators.coolingPowerW = 0;
        this.actuators.lights = false;
        this.actuators.lightsState = 'OFF';
        this.actuators.lightsPowerW = 0;

        reasoning = `Room is unoccupied (Vacant). Activating Energy-Saving Mode. Cooling and lighting systems automatically turned OFF to conserve power, overriding thermal (${this.sensors.temperature}°C) and ambient light (${this.sensors.ambientLight}%) demands.`;

        triggeredRules.push({
          id: 'RULE_2',
          name: 'Empty Room Energy Conservation',
          priority: 2,
          status: 'FIRED_ACTIVE',
          details: `Occupancy=FALSE. Forcing cooling=OFF, lights=OFF, energySaving=ACTIVE.`
        });

      } else {
        // =====================================================================
        // PRIORITY 3 & 4: ROOM OCCUPIED - COMFORT & LIGHTING RULES
        // =====================================================================
        this.actuators.energySaving = false;
        const comfortReasons = [];

        // Requirement 6: Automatic cooling system activation when temperature reaches 30°C.
        const coolingNeeded = (this.sensors.temperature >= this.THRESHOLDS.COOLING_TEMP_C);
        if (coolingNeeded) {
          this.actuators.cooling = true;
          this.actuators.coolingState = 'ACTIVE';
          this.actuators.coolingPowerW = this.THRESHOLDS.AC_POWER_W;
          comfortReasons.push(`Temperature (${this.sensors.temperature}°C >= ${this.THRESHOLDS.COOLING_TEMP_C}°C threshold) -> Cooling System ACTIVATED`);
          triggeredRules.push({
            id: 'RULE_3',
            name: 'Automatic Temperature Cooling',
            priority: 3,
            status: 'FIRED_ACTIVE',
            details: `Temp ${this.sensors.temperature}°C >= 30°C and Room Occupied. Cooling ON.`
          });
        } else {
          this.actuators.cooling = false;
          this.actuators.coolingState = 'OFF';
          this.actuators.coolingPowerW = 0;
          triggeredRules.push({
            id: 'RULE_3',
            name: 'Automatic Temperature Cooling',
            priority: 3,
            status: 'STANDBY',
            details: `Temp ${this.sensors.temperature}°C < 30°C threshold. Cooling remains OFF.`
          });
        }

        // Requirement 7: Automatic lights ON when a person is present and light level is below 35%.
        const lightsNeeded = (this.sensors.ambientLight < this.THRESHOLDS.LIGHT_PERCENT);
        if (lightsNeeded) {
          this.actuators.lights = true;
          this.actuators.lightsState = 'ACTIVE';
          this.actuators.lightsPowerW = this.THRESHOLDS.LIGHTS_POWER_W;
          comfortReasons.push(`Ambient Light (${this.sensors.ambientLight}% < ${this.THRESHOLDS.LIGHT_PERCENT}% threshold) -> Smart Lights ACTIVATED`);
          triggeredRules.push({
            id: 'RULE_4',
            name: 'Ambient Light Automation',
            priority: 4,
            status: 'FIRED_ACTIVE',
            details: `Light ${this.sensors.ambientLight}% < 35% and Room Occupied. Lights ON.`
          });
        } else {
          this.actuators.lights = false;
          this.actuators.lightsState = 'OFF';
          this.actuators.lightsPowerW = 0;
          triggeredRules.push({
            id: 'RULE_4',
            name: 'Ambient Light Automation',
            priority: 4,
            status: 'STANDBY',
            details: `Light ${this.sensors.ambientLight}% >= 35% threshold. Natural light adequate, lights remain OFF.`
          });
        }

        // Determine composite active rule identity
        if (coolingNeeded && lightsNeeded) {
          activeRuleId = 'RULE_3_4_COMFORT_COMBO';
          activeRuleName = 'Active Cooling & Lighting';
          priorityLevel = 3;
          priorityLabel = 'Medium (Priority 3 & 4)';
          reasoning = `Room occupied. Both conditions met: ${comfortReasons.join('; ')}.`;
        } else if (coolingNeeded) {
          activeRuleId = 'RULE_3_COOLING';
          activeRuleName = 'Thermal Cooling Active';
          priorityLevel = 3;
          priorityLabel = 'Medium (Priority 3)';
          reasoning = `Room occupied. ${comfortReasons[0]}. Natural light is sufficient (${this.sensors.ambientLight}% >= 35%).`;
        } else if (lightsNeeded) {
          activeRuleId = 'RULE_4_LIGHTING';
          activeRuleName = 'Smart Lighting Active';
          priorityLevel = 4;
          priorityLabel = 'Normal (Priority 4)';
          reasoning = `Room occupied. ${comfortReasons[0]}. Temperature is comfortable (${this.sensors.temperature}°C < 30°C).`;
        } else {
          activeRuleId = 'RULE_STANDBY';
          activeRuleName = 'Comfort Standby';
          priorityLevel = 5;
          priorityLabel = 'Nominal';
          reasoning = `Room occupied. Temperature (${this.sensors.temperature}°C) is comfortable (<30°C) and ambient light (${this.sensors.ambientLight}%) is sufficient (>=35%). Actuators in standby.`;
        }
      }
    }

    // Update agent decision record
    this.decision = {
      activeRuleId,
      activeRuleName,
      priorityLevel,
      priorityLabel,
      reasoning,
      triggeredRules,
      timestamp: new Date()
    };

    // Detect and log state transitions
    this.logStateTransitions(prevState);

    return this.getState();
  }

  /**
   * Compares previous actuator states to new states and generates log events
   */
  logStateTransitions(prevState) {
    const timestamp = new Date();
    const timeStr = timestamp.toLocaleTimeString('en-US', { hour12: false }) + '.' + 
                    String(timestamp.getMilliseconds()).padStart(3, '0');

    // Emergency Transition
    if (!prevState.emergencyWarning && this.actuators.emergencyWarning) {
      this.addLog({
        time: timeStr,
        timestamp,
        category: 'EMERGENCY',
        badgeClass: 'badge-danger',
        event: 'Smoke Emergency Triggered',
        rule: 'Rule 1: Smoke Emergency Override (Priority 1)',
        details: 'Smoke detected. Repeating audible siren and browser notification triggered. Cooling shutdown, emergency lights activated.',
        stateChange: 'NORMAL -> CRITICAL EMERGENCY'
      });
    } else if (prevState.emergencyWarning && !this.actuators.emergencyWarning) {
      this.addLog({
        time: timeStr,
        timestamp,
        category: 'EMERGENCY',
        badgeClass: 'badge-success',
        event: 'Smoke Cleared / Hazard Normal',
        rule: 'Safety Check',
        details: 'Smoke sensor returned to normal clear state. Emergency alarm and visual warning deactivated.',
        stateChange: 'CRITICAL EMERGENCY -> NORMAL'
      });
    }

    // Cooling System Transition
    if (prevState.cooling !== this.actuators.cooling) {
      if (this.actuators.cooling) {
        this.addLog({
          time: timeStr,
          timestamp,
          category: 'COOLING',
          badgeClass: 'badge-primary',
          event: 'Cooling System Started',
          rule: 'Rule 3: Automatic Cooling (Priority 3)',
          details: `Temperature reached ${this.sensors.temperature}°C (>= 30°C threshold). AC compressor activated.`,
          stateChange: 'Cooling: OFF -> ON'
        });
      } else {
        const reason = this.sensors.smoke ? 'Emergency Safety Shutdown' : 
                      (!this.sensors.occupancy ? 'Empty Room Energy-Saving' : `Temperature dropped below 30°C (${this.sensors.temperature}°C)`);
        this.addLog({
          time: timeStr,
          timestamp,
          category: 'COOLING',
          badgeClass: 'badge-secondary',
          event: 'Cooling System Stopped',
          rule: this.sensors.smoke ? 'Rule 1 (Override)' : (!this.sensors.occupancy ? 'Rule 2 (Eco Mode)' : 'Rule 3 (Normal)'),
          details: `Cooling stopped due to: ${reason}.`,
          stateChange: 'Cooling: ON -> OFF'
        });
      }
    }

    // Lighting Transition
    if (prevState.lights !== this.actuators.lights) {
      if (this.actuators.lights) {
        const reason = this.sensors.smoke ? 'Emergency Safe-Path Illumination' : `Ambient light is ${this.sensors.ambientLight}% (< 35%) with occupant present`;
        this.addLog({
          time: timeStr,
          timestamp,
          category: 'LIGHTING',
          badgeClass: 'badge-warning',
          event: 'Smart Lights Switched ON',
          rule: this.sensors.smoke ? 'Rule 1 (Emergency)' : 'Rule 4: Ambient Light Automation (Priority 4)',
          details: `Lighting activated: ${reason}.`,
          stateChange: 'Lights: OFF -> ON'
        });
      } else {
        const reason = !this.sensors.occupancy ? 'Room unoccupied (Energy-Saving)' : `Natural light is sufficient (${this.sensors.ambientLight}% >= 35%)`;
        this.addLog({
          time: timeStr,
          timestamp,
          category: 'LIGHTING',
          badgeClass: 'badge-secondary',
          event: 'Smart Lights Switched OFF',
          rule: !this.sensors.occupancy ? 'Rule 2 (Energy-Saving)' : 'Rule 4: Ambient Light Automation',
          details: `Lighting turned off: ${reason}.`,
          stateChange: 'Lights: ON -> OFF'
        });
      }
    }

    // Energy Saving Transition
    if (prevState.energySaving !== this.actuators.energySaving) {
      if (this.actuators.energySaving) {
        this.addLog({
          time: timeStr,
          timestamp,
          category: 'ENERGY',
          badgeClass: 'badge-eco',
          event: 'Energy-Saving Mode ACTIVATED',
          rule: 'Rule 2: Empty Room Energy Conservation (Priority 2)',
          details: 'Occupancy sensor reports room vacant. Forced cooling and lights to OFF.',
          stateChange: 'Eco Mode: INACTIVE -> ACTIVE'
        });
      } else {
        this.addLog({
          time: timeStr,
          timestamp,
          category: 'ENERGY',
          badgeClass: 'badge-secondary',
          event: 'Energy-Saving Mode DEACTIVATED',
          rule: this.sensors.smoke ? 'Rule 1 (Emergency Override)' : 'Occupancy Detected',
          details: this.sensors.smoke ? 'Overridden by emergency alert.' : 'Occupant entered the room. Normal comfort control restored.',
          stateChange: 'Eco Mode: ACTIVE -> INACTIVE'
        });
      }
    }
  }

  /**
   * Append an entry to the action log (capped at 500 entries)
   */
  addLog(entry) {
    this.actionLogs.unshift({
      id: 'log_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      ...entry
    });
    if (this.actionLogs.length > 500) {
      this.actionLogs.pop();
    }
  }

  /**
   * Reset all sensors and actuators to default safe state
   */
  reset() {
    this.sensors = {
      temperature: 24.0,
      occupancy: true,
      ambientLight: 60.0,
      smoke: false
    };

    const result = this.evaluate();
    const timeStr = new Date().toLocaleTimeString('en-US', { hour12: false });
    this.addLog({
      time: timeStr,
      timestamp: new Date(),
      category: 'SYSTEM',
      badgeClass: 'badge-info',
      event: 'System Baseline Reset',
      rule: 'User / System Command',
      details: 'All simulated sensors reset to nominal baseline: Temp=24°C, Occupied=ON, Light=60%, Smoke=OFF.',
      stateChange: 'REINITIALIZED'
    });
    return result;
  }

  /**
   * Clear the action log
   */
  clearLogs() {
    this.actionLogs = [];
  }

  /**
   * Return full snapshot of agent state
   */
  getState() {
    // Calculate simulated power
    let currentPowerW = this.THRESHOLDS.BASE_STANDBY_W;
    if (this.actuators.cooling) currentPowerW += this.actuators.coolingPowerW;
    if (this.actuators.lights) currentPowerW += this.actuators.lightsPowerW;
    if (this.actuators.emergencyWarning) currentPowerW += 40; // alarm horn + strobe

    const potentialMaxPower = this.THRESHOLDS.BASE_STANDBY_W + this.THRESHOLDS.AC_POWER_W + this.THRESHOLDS.LIGHTS_POWER_W;
    const powerSavedW = this.actuators.energySaving ? (this.THRESHOLDS.AC_POWER_W + this.THRESHOLDS.LIGHTS_POWER_W) : (potentialMaxPower - currentPowerW);

    return {
      sensors: { ...this.sensors },
      actuators: { ...this.actuators },
      decision: { ...this.decision },
      power: {
        currentW: currentPowerW,
        savedW: Math.max(0, powerSavedW),
        status: this.actuators.energySaving ? 'ECO_SAVING' : (this.actuators.emergencyWarning ? 'EMERGENCY' : 'NORMAL')
      },
      logCount: this.actionLogs.length
    };
  }
}

// Export for browser and Node.js testing environments
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { SmartHomeAgent };
} else {
  window.SmartHomeAgent = SmartHomeAgent;
}
