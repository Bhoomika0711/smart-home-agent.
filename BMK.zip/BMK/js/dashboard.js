/**
 * Dashboard Controller & User Interface Engine
 * Binds UI components to the Intelligent Agent, Audio Synthesizer, and Notifications.
 */

document.addEventListener('DOMContentLoaded', () => {
  // Initialize Subsystems
  const agent = new SmartHomeAgent();
  const audio = new SoundSynthesizer();
  const notifier = new NotificationManager();
  const testSuite = new AgentTestSuite();

  // State flags for interactive demos
  let simulationRunning = false;
  let simulationTimer = null;
  let activeLogFilter = 'ALL';

  // DOM Elements Cache
  const els = {
    // Top Bar & Emergency Banner
    emergencyBanner: document.getElementById('emergency-banner'),
    emergencyReason: document.getElementById('emergency-reason'),
    btnDismissEmergency: document.getElementById('btn-dismiss-emergency'),
    btnMuteSiren: document.getElementById('btn-mute-siren'),
    btnEnableNotifications: document.getElementById('btn-enable-notifications'),
    notifStatusBadge: document.getElementById('notif-status-badge'),
    sirenVolume: document.getElementById('siren-volume'),

    // Sensors
    tempSlider: document.getElementById('temp-slider'),
    tempNumber: document.getElementById('temp-number'),
    tempDisplay: document.getElementById('temp-display'),
    tempStatus: document.getElementById('temp-status'),
    tempGaugeFill: document.getElementById('temp-gauge-fill'),

    occupancyToggle: document.getElementById('occupancy-toggle'),
    occupancyBadge: document.getElementById('occupancy-badge'),
    occupancyAvatar: document.getElementById('occupancy-avatar'),
    occupancyLabel: document.getElementById('occupancy-label'),

    lightSlider: document.getElementById('light-slider'),
    lightNumber: document.getElementById('light-number'),
    lightDisplay: document.getElementById('light-display'),
    lightStatus: document.getElementById('light-status'),
    lightGaugeFill: document.getElementById('light-gauge-fill'),
    lightPreviewBox: document.getElementById('light-preview-box'),

    smokeToggle: document.getElementById('smoke-toggle'),
    smokeBadge: document.getElementById('smoke-badge'),
    smokeCard: document.getElementById('smoke-card'),

    // Actuators
    coolingCard: document.getElementById('cooling-card'),
    coolingStateBadge: document.getElementById('cooling-state-badge'),
    coolingFanIcon: document.getElementById('cooling-fan-icon'),
    coolingPowerText: document.getElementById('cooling-power-text'),
    coolingDesc: document.getElementById('cooling-desc'),

    lightingCard: document.getElementById('lighting-card'),
    lightingStateBadge: document.getElementById('lighting-state-badge'),
    lightingBulbIcon: document.getElementById('lighting-bulb-icon'),
    lightingPowerText: document.getElementById('lighting-power-text'),
    lightingDesc: document.getElementById('lighting-desc'),

    energyCard: document.getElementById('energy-card'),
    energyStateBadge: document.getElementById('energy-state-badge'),
    energyLeafIcon: document.getElementById('energy-leaf-icon'),
    energyPowerText: document.getElementById('energy-power-text'),
    energyDesc: document.getElementById('energy-desc'),

    emergencyCard: document.getElementById('emergency-card'),
    emergencyCardBadge: document.getElementById('emergency-card-badge'),
    emergencySirenIcon: document.getElementById('emergency-siren-icon'),
    emergencyAlarmText: document.getElementById('emergency-alarm-text'),
    emergencyCardDesc: document.getElementById('emergency-card-desc'),

    // Live Metrics
    livePowerTotal: document.getElementById('live-power-total'),
    livePowerSaved: document.getElementById('live-power-saved'),
    liveActiveRule: document.getElementById('live-active-rule'),
    liveAgentReasoning: document.getElementById('live-agent-reasoning'),
    livePriorityBadge: document.getElementById('live-priority-badge'),

    // Action Log
    actionLogBody: document.getElementById('action-log-body'),
    logCountBadge: document.getElementById('log-count-badge'),
    btnClearLogs: document.getElementById('btn-clear-logs'),
    btnExportCsv: document.getElementById('btn-export-csv'),
    btnExportJson: document.getElementById('btn-export-json'),
    logFilterButtons: document.querySelectorAll('.log-filter-btn'),

    // Assignment Test Suite Controls
    btnRunSimulation: document.getElementById('btn-run-simulation'),
    simulationProgress: document.getElementById('simulation-progress'),
    simulationProgressBar: document.getElementById('simulation-progress-bar'),
    simulationStatusText: document.getElementById('simulation-status-text'),
    btnTestCase1: document.getElementById('btn-test-case-1'),
    btnTestCase2: document.getElementById('btn-test-case-2'),
    btnTestCase3: document.getElementById('btn-test-case-3'),
    btnTestCase4: document.getElementById('btn-test-case-4'),
    btnTestCase5: document.getElementById('btn-test-case-5'),

    // Master Controls
    btnResetSystem: document.getElementById('btn-reset-system'),
    btnTestEmergencyAlarm: document.getElementById('btn-test-emergency-alarm'),
    btnRunAutomatedTests: document.getElementById('btn-run-automated-tests'),

    // Automated Tests Modal
    testModal: document.getElementById('test-modal'),
    btnCloseTestModal: document.getElementById('btn-close-test-modal'),
    testSummaryBanner: document.getElementById('test-summary-banner'),
    testResultsList: document.getElementById('test-results-list'),

    // Rule Status Badges
    rule1Status: document.getElementById('rule-1-status'),
    rule2Status: document.getElementById('rule-2-status'),
    rule3Status: document.getElementById('rule-3-status'),
    rule4Status: document.getElementById('rule-4-status')
  };

  // =========================================================================
  // 1. UI RENDER & SYNCHRONIZATION FUNCTION
  // =========================================================================
  function renderDashboard(state) {
    const { sensors, actuators, decision, power } = state;

    // --- SENSORS RENDERING ---
    // Temperature
    els.tempSlider.value = sensors.temperature;
    els.tempNumber.value = sensors.temperature;
    els.tempDisplay.textContent = `${sensors.temperature.toFixed(1)}°C`;
    
    // Gauge percentage (range 10 to 45°C)
    const tempPercent = Math.max(0, Math.min(100, ((sensors.temperature - 10) / 35) * 100));
    els.tempGaugeFill.style.width = `${tempPercent}%`;
    
    if (sensors.temperature >= 30.0) {
      els.tempStatus.innerHTML = '<span class="status-indicator hot">HOT &ge; 30°C (Cooling Required)</span>';
      els.tempGaugeFill.style.backgroundColor = '#ef4444';
    } else if (sensors.temperature >= 24.0) {
      els.tempStatus.innerHTML = '<span class="status-indicator warm">WARM (Comfortable)</span>';
      els.tempGaugeFill.style.backgroundColor = '#f59e0b';
    } else {
      els.tempStatus.innerHTML = '<span class="status-indicator cool">COOL (Optimal)</span>';
      els.tempGaugeFill.style.backgroundColor = '#3b82f6';
    }

    // Occupancy
    els.occupancyToggle.checked = sensors.occupancy;
    if (sensors.occupancy) {
      els.occupancyBadge.className = 'badge badge-success';
      els.occupancyBadge.textContent = 'OCCUPIED';
      els.occupancyLabel.textContent = 'Person Present in Room';
      els.occupancyAvatar.classList.add('occupied');
    } else {
      els.occupancyBadge.className = 'badge badge-secondary';
      els.occupancyBadge.textContent = 'VACANT';
      els.occupancyLabel.textContent = 'Room is Empty';
      els.occupancyAvatar.classList.remove('occupied');
    }

    // Ambient Light
    els.lightSlider.value = sensors.ambientLight;
    els.lightNumber.value = sensors.ambientLight;
    els.lightDisplay.textContent = `${sensors.ambientLight.toFixed(0)}%`;
    els.lightGaugeFill.style.width = `${sensors.ambientLight}%`;
    
    // Calculate approximate Lux (0% = 0 lux, 100% = 800 lux)
    const approxLux = Math.round((sensors.ambientLight / 100) * 800);
    els.lightPreviewBox.style.backgroundColor = `rgba(251, 191, 36, ${sensors.ambientLight / 100})`;
    
    if (sensors.ambientLight < 35.0) {
      els.lightStatus.innerHTML = `<span class="status-indicator dim">DIM &lt; 35% (~${approxLux} Lux)</span>`;
      els.lightGaugeFill.style.backgroundColor = '#f59e0b';
    } else {
      els.lightStatus.innerHTML = `<span class="status-indicator bright">BRIGHT &ge; 35% (~${approxLux} Lux)</span>`;
      els.lightGaugeFill.style.backgroundColor = '#10b981';
    }

    // Smoke Sensor
    els.smokeToggle.checked = sensors.smoke;
    if (sensors.smoke) {
      els.smokeBadge.className = 'badge badge-danger-animated';
      els.smokeBadge.textContent = 'HAZARD DETECTED!';
      els.smokeCard.classList.add('sensor-alert');
    } else {
      els.smokeBadge.className = 'badge badge-outline-success';
      els.smokeBadge.textContent = 'NORMAL / CLEAR';
      els.smokeCard.classList.remove('sensor-alert');
    }

    // --- ACTUATORS RENDERING ---
    // Cooling System (AC)
    if (actuators.cooling) {
      els.coolingCard.className = 'actuator-card active-cooling';
      els.coolingStateBadge.className = 'badge badge-primary';
      els.coolingStateBadge.textContent = 'ACTIVE (ON)';
      els.coolingFanIcon.classList.add('spinning-fast');
      els.coolingPowerText.textContent = `${actuators.coolingPowerW} W`;
      els.coolingDesc.textContent = `Compressor cooling active. Temp: ${sensors.temperature}°C >= 30°C threshold.`;
    } else if (actuators.coolingState === 'EMERGENCY_SHUTDOWN') {
      els.coolingCard.className = 'actuator-card emergency-shutdown';
      els.coolingStateBadge.className = 'badge badge-danger';
      els.coolingStateBadge.textContent = 'EMERGENCY SHUTDOWN';
      els.coolingFanIcon.classList.remove('spinning-fast');
      els.coolingPowerText.textContent = '0 W';
      els.coolingDesc.textContent = 'HVAC safely halted to prevent spreading smoke through ventilation.';
    } else {
      els.coolingCard.className = 'actuator-card';
      els.coolingStateBadge.className = 'badge badge-secondary';
      els.coolingStateBadge.textContent = 'STANDBY (OFF)';
      els.coolingFanIcon.classList.remove('spinning-fast');
      els.coolingPowerText.textContent = '0 W';
      els.coolingDesc.textContent = sensors.occupancy ? 'Temp below 30°C comfort threshold.' : 'Room vacant: Cooling powered down.';
    }

    // Smart Lighting
    if (actuators.lights) {
      if (actuators.lightsState === 'EMERGENCY_ILLUMINATION') {
        els.lightingCard.className = 'actuator-card emergency-lighting';
        els.lightingStateBadge.className = 'badge badge-danger';
        els.lightingStateBadge.textContent = 'EMERGENCY ILLUMINATION';
        els.lightingBulbIcon.classList.add('bulb-emergency-strobe');
        els.lightingPowerText.textContent = `${actuators.lightsPowerW} W`;
        els.lightingDesc.textContent = 'Emergency egress lighting illuminated for safe evacuation.';
      } else {
        els.lightingCard.className = 'actuator-card active-lighting';
        els.lightingStateBadge.className = 'badge badge-warning';
        els.lightingStateBadge.textContent = 'ACTIVE (ON)';
        els.lightingBulbIcon.classList.add('bulb-active');
        els.lightingBulbIcon.classList.remove('bulb-emergency-strobe');
        els.lightingPowerText.textContent = `${actuators.lightsPowerW} W`;
        els.lightingDesc.textContent = `Illuminating room: Ambient light is ${sensors.ambientLight}% (< 35%) & occupant present.`;
      }
    } else {
      els.lightingCard.className = 'actuator-card';
      els.lightingStateBadge.className = 'badge badge-secondary';
      els.lightingStateBadge.textContent = 'OFF';
      els.lightingBulbIcon.classList.remove('bulb-active', 'bulb-emergency-strobe');
      els.lightingPowerText.textContent = '0 W';
      els.lightingDesc.textContent = sensors.occupancy ? 'Natural ambient light sufficient (>= 35%).' : 'Room vacant: Lights turned off.';
    }

    // Energy Saving Mode
    if (actuators.energySaving) {
      els.energyCard.className = 'actuator-card active-eco';
      els.energyStateBadge.className = 'badge badge-eco';
      els.energyStateBadge.textContent = 'ACTIVE';
      els.energyLeafIcon.classList.add('pulse-eco');
      els.energyPowerText.textContent = `Saving ~${power.savedW} W`;
      els.energyDesc.textContent = 'Unoccupied room detected. Standby eco mode engaged. Cooling & lights forced OFF.';
    } else {
      els.energyCard.className = 'actuator-card';
      els.energyStateBadge.className = 'badge badge-secondary';
      els.energyStateBadge.textContent = 'INACTIVE';
      els.energyLeafIcon.classList.remove('pulse-eco');
      els.energyPowerText.textContent = 'Standard Power';
      els.energyDesc.textContent = actuators.emergencyWarning ? 'Emergency safety takes precedence.' : 'Room occupied: comfort control active.';
    }

    // Emergency Warning System Actuator Card
    if (actuators.emergencyWarning) {
      els.emergencyCard.className = 'actuator-card active-emergency-card';
      els.emergencyCardBadge.className = 'badge badge-danger-animated';
      els.emergencyCardBadge.textContent = 'CRITICAL ALERT';
      els.emergencySirenIcon.classList.add('alarm-pulse-anim');
      els.emergencyAlarmText.textContent = audio.isMuted ? 'SIREN ACTIVE (MUTED)' : 'SIREN SOUNDING';
      els.emergencyCardDesc.textContent = 'Smoke detected! Repeating audio siren and browser notification triggered. Overriding all rules.';

      // Activate Top Banner
      els.emergencyBanner.classList.remove('hidden');
      els.emergencyReason.textContent = 'SMOKE DETECTED! Repeating audible alarm is sounding. Browser notifications dispatched. Cooling disabled, evacuation lighting engaged.';

      // Sound siren via Web Audio API
      audio.startAlarm();

      // Trigger browser notification
      notifier.triggerEmergencyAlert(
        'SMOKE EMERGENCY ALERT!',
        'Smoke detected by indoor safety sensor! Repeating siren sounding. Cooling shutdown. Evacuate immediately.'
      );

    } else {
      els.emergencyCard.className = 'actuator-card';
      els.emergencyCardBadge.className = 'badge badge-secondary';
      els.emergencyCardBadge.textContent = 'NORMAL';
      els.emergencySirenIcon.classList.remove('alarm-pulse-anim');
      els.emergencyAlarmText.textContent = 'Alarm Standby';
      els.emergencyCardDesc.textContent = 'Continuous safety monitoring active. Ready to override on smoke event.';

      // Hide Top Banner
      els.emergencyBanner.classList.add('hidden');

      // Stop siren
      audio.stopAlarm();
    }

    // --- AGENT REASONING & METRICS ---
    els.livePowerTotal.textContent = `${power.currentW} W`;
    els.livePowerSaved.textContent = `${power.savedW} W`;
    els.liveActiveRule.textContent = decision.activeRuleName;
    els.liveAgentReasoning.textContent = decision.reasoning;
    els.livePriorityBadge.textContent = decision.priorityLabel;

    if (decision.priorityLevel === 1) {
      els.livePriorityBadge.className = 'badge badge-danger-animated';
    } else if (decision.priorityLevel === 2) {
      els.livePriorityBadge.className = 'badge badge-eco';
    } else if (decision.priorityLevel === 3) {
      els.livePriorityBadge.className = 'badge badge-primary';
    } else {
      els.livePriorityBadge.className = 'badge badge-secondary';
    }

    // Update Knowledge Base Rule Status Indicators
    updateRuleTableStatus(decision);

    // Update Action Log Table
    renderActionLogs();
  }

  // Update rule breakdown table status tags
  function updateRuleTableStatus(decision) {
    els.rule1Status.className = 'badge ' + (agent.sensors.smoke ? 'badge-danger-animated' : 'badge-secondary');
    els.rule1Status.textContent = agent.sensors.smoke ? 'ACTIVE (PRIORITY 1)' : 'STANDBY';

    els.rule2Status.className = 'badge ' + (!agent.sensors.smoke && !agent.sensors.occupancy ? 'badge-eco' : (agent.sensors.smoke ? 'badge-dimmed' : 'badge-secondary'));
    els.rule2Status.textContent = agent.sensors.smoke ? 'OVERRIDDEN' : (!agent.sensors.occupancy ? 'ACTIVE (PRIORITY 2)' : 'STANDBY');

    const coolingFired = !agent.sensors.smoke && agent.sensors.occupancy && agent.sensors.temperature >= 30.0;
    els.rule3Status.className = 'badge ' + (coolingFired ? 'badge-primary' : (agent.sensors.smoke || !agent.sensors.occupancy ? 'badge-dimmed' : 'badge-secondary'));
    els.rule3Status.textContent = coolingFired ? 'ACTIVE (PRIORITY 3)' : (agent.sensors.smoke ? 'OVERRIDDEN (SAFETY)' : (!agent.sensors.occupancy ? 'OVERRIDDEN (ECO)' : 'STANDBY'));

    const lightingFired = !agent.sensors.smoke && agent.sensors.occupancy && agent.sensors.ambientLight < 35.0;
    els.rule4Status.className = 'badge ' + (lightingFired ? 'badge-warning' : (agent.sensors.smoke ? 'badge-danger' : (!agent.sensors.occupancy ? 'badge-dimmed' : 'badge-secondary')));
    els.rule4Status.textContent = lightingFired ? 'ACTIVE (PRIORITY 4)' : (agent.sensors.smoke ? 'EMERGENCY MODE' : (!agent.sensors.occupancy ? 'OVERRIDDEN (ECO)' : 'STANDBY'));
  }

  // =========================================================================
  // 2. ACTION LOG RENDERING & EXPORTS
  // =========================================================================
  function renderActionLogs() {
    const logs = agent.actionLogs;
    els.logCountBadge.textContent = `${logs.length} Events`;

    const filtered = logs.filter(log => {
      if (activeLogFilter === 'ALL') return true;
      return log.category === activeLogFilter;
    });

    if (filtered.length === 0) {
      els.actionLogBody.innerHTML = `
        <tr class="empty-log-row">
          <td colspan="5" class="text-center text-muted">No action log entries for category: ${activeLogFilter}</td>
        </tr>
      `;
      return;
    }

    const html = filtered.slice(0, 50).map(log => `
      <tr class="log-row ${log.category === 'EMERGENCY' ? 'log-emergency-row' : ''}">
        <td class="log-time"><code>${log.time}</code></td>
        <td><span class="badge ${log.badgeClass}">${log.category}</span></td>
        <td class="log-event"><strong>${escapeHtml(log.event)}</strong></td>
        <td class="log-state"><small>${escapeHtml(log.stateChange)}</small></td>
        <td class="log-details">${escapeHtml(log.details)}</td>
      </tr>
    `).join('');

    els.actionLogBody.innerHTML = html;
  }

  function escapeHtml(text) {
    if (!text) return '';
    return text.toString()
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  // CSV Export
  function exportLogsCsv() {
    const logs = agent.actionLogs;
    if (logs.length === 0) {
      notifier.showToast('Export Empty', 'Action log has no entries to export.', 'warning');
      return;
    }
    const headers = ['Timestamp', 'Category', 'Event', 'State Change', 'Rule', 'Details'];
    const rows = logs.map(l => [
      `"${l.time}"`,
      `"${l.category}"`,
      `"${l.event.replace(/"/g, '""')}"`,
      `"${l.stateChange.replace(/"/g, '""')}"`,
      `"${(l.rule || '').replace(/"/g, '""')}"`,
      `"${l.details.replace(/"/g, '""')}"`
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `smart_home_agent_log_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    link.remove();
    notifier.showToast('CSV Exported', `Saved ${logs.length} log events to CSV file.`, 'success');
  }

  // JSON Export
  function exportLogsJson() {
    const logs = agent.actionLogs;
    if (logs.length === 0) {
      notifier.showToast('Export Empty', 'Action log has no entries to export.', 'warning');
      return;
    }
    const jsonStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(logs, null, 2));
    const link = document.createElement('a');
    link.setAttribute('href', jsonStr);
    link.setAttribute('download', `smart_home_agent_log_${Date.now()}.json`);
    document.body.appendChild(link);
    link.click();
    link.remove();
    notifier.showToast('JSON Exported', `Saved ${logs.length} log events to JSON file.`, 'success');
  }

  // =========================================================================
  // 3. SENSOR EVENT HANDLERS
  // =========================================================================
  // Temperature controls
  function setTemperature(val) {
    const num = Math.min(45, Math.max(10, parseFloat(val) || 24));
    audio.playChime('click');
    agent.updateSensors({ temperature: num });
    renderDashboard(agent.getState());
  }

  els.tempSlider.addEventListener('input', (e) => setTemperature(e.target.value));
  els.tempNumber.addEventListener('change', (e) => setTemperature(e.target.value));

  document.querySelectorAll('.btn-temp-preset').forEach(btn => {
    btn.addEventListener('click', () => {
      setTemperature(btn.getAttribute('data-temp'));
    });
  });

  // Occupancy control
  function setOccupancy(val) {
    audio.playChime('click');
    agent.updateSensors({ occupancy: !!val });
    renderDashboard(agent.getState());
  }

  els.occupancyToggle.addEventListener('change', (e) => setOccupancy(e.target.checked));

  document.getElementById('btn-occupancy-occupied')?.addEventListener('click', () => setOccupancy(true));
  document.getElementById('btn-occupancy-vacant')?.addEventListener('click', () => setOccupancy(false));

  // Ambient Light controls
  function setLight(val) {
    const num = Math.min(100, Math.max(0, parseFloat(val) || 50));
    audio.playChime('click');
    agent.updateSensors({ ambientLight: num });
    renderDashboard(agent.getState());
  }

  els.lightSlider.addEventListener('input', (e) => setLight(e.target.value));
  els.lightNumber.addEventListener('change', (e) => setLight(e.target.value));

  document.querySelectorAll('.btn-light-preset').forEach(btn => {
    btn.addEventListener('click', () => {
      setLight(btn.getAttribute('data-light'));
    });
  });

  // Smoke Sensor control
  function setSmoke(val) {
    audio.playChime('click');
    agent.updateSensors({ smoke: !!val });
    renderDashboard(agent.getState());
  }

  els.smokeToggle.addEventListener('change', (e) => setSmoke(e.target.checked));

  document.getElementById('btn-smoke-trigger')?.addEventListener('click', () => setSmoke(true));
  document.getElementById('btn-smoke-clear')?.addEventListener('click', () => setSmoke(false));

  // =========================================================================
  // 4. EMERGENCY, ALARM & NOTIFICATION CONTROLS
  // =========================================================================
  // Dismiss emergency banner / clear smoke
  els.btnDismissEmergency.addEventListener('click', () => {
    setSmoke(false);
    notifier.showToast('Emergency Cleared', 'Smoke hazard cleared. System returned to nominal operating mode.', 'info');
  });

  // Mute / Unmute siren
  els.btnMuteSiren.addEventListener('click', () => {
    const muted = audio.toggleMute();
    els.btnMuteSiren.textContent = muted ? 'Unmute Siren 🔊' : 'Mute Siren 🔇';
    els.emergencyAlarmText.textContent = muted ? 'SIREN ACTIVE (MUTED)' : 'SIREN SOUNDING';
    notifier.showToast('Audio Control', muted ? 'Audible siren muted.' : 'Audible siren unmuted.', 'info');
  });

  // Volume Slider
  els.sirenVolume.addEventListener('input', (e) => {
    audio.setVolume(e.target.value);
  });

  // Enable Browser System Notifications button
  els.btnEnableNotifications.addEventListener('click', async () => {
    const perm = await notifier.requestPermission();
    updateNotificationPermissionStatus();
  });

  function updateNotificationPermissionStatus() {
    if (!('Notification' in window)) {
      els.notifStatusBadge.textContent = 'Not Supported';
      els.notifStatusBadge.className = 'badge badge-secondary';
      return;
    }
    const perm = Notification.permission;
    if (perm === 'granted') {
      els.notifStatusBadge.textContent = 'Active (Granted)';
      els.notifStatusBadge.className = 'badge badge-success';
      els.btnEnableNotifications.textContent = 'Notifications Enabled ✓';
      els.btnEnableNotifications.disabled = true;
    } else if (perm === 'denied') {
      els.notifStatusBadge.textContent = 'Blocked';
      els.notifStatusBadge.className = 'badge badge-danger';
    } else {
      els.notifStatusBadge.textContent = 'Pending Permission';
      els.notifStatusBadge.className = 'badge badge-warning';
    }
  }

  // =========================================================================
  // 5. MASTER BUTTONS: RESET & EMERGENCY ALARM TEST
  // =========================================================================
  // Reset System Button (Requirement 13)
  els.btnResetSystem.addEventListener('click', () => {
    stopSimulationIfRunning();
    audio.playChime('test');
    agent.reset();
    renderDashboard(agent.getState());
    notifier.showToast('System Reset Complete', 'Simulated sensors reset to safe baseline: Temp 24°C, Occupancy ON, Light 60%, Smoke OFF.', 'success');
  });

  // Emergency Alarm Test Button (Requirement 13)
  els.btnTestEmergencyAlarm.addEventListener('click', () => {
    audio.playChime('click');
    notifier.showToast('Emergency Alarm Test Drill', 'Testing multi-sensory emergency alarm! Siren sounding for 6 seconds.', 'warning');
    // Set smoke sensor to TRUE to trigger emergency warning
    agent.updateSensors({ smoke: true });
    renderDashboard(agent.getState());

    // Auto-restore after 6 seconds drill
    setTimeout(() => {
      if (agent.sensors.smoke) {
        agent.updateSensors({ smoke: false });
        renderDashboard(agent.getState());
        notifier.showToast('Emergency Drill Concluded', 'Emergency alarm test completed successfully. Smoke cleared.', 'info');
      }
    }, 6000);
  });

  // =========================================================================
  // 6. ASSIGNMENT TEST CASE BUTTONS (1-CLICK DEMONSTRATIONS)
  // =========================================================================
  function applyTestCase(tcNumber) {
    stopSimulationIfRunning();
    audio.playChime('click');

    switch (tcNumber) {
      case 1:
        // Test Case 1: Temp >= 30°C -> Cooling ON
        agent.updateSensors({
          temperature: 32.0,
          occupancy: true,
          ambientLight: 55.0,
          smoke: false
        });
        notifier.showToast(
          'Test Case 1 Applied: High Temperature',
          'Temp: 32°C (>= 30°C), Occupied: YES, Light: 55%, Smoke: NO -> Result: Cooling ACTIVATED, Lights OFF, Eco INACTIVE.',
          'info',
          5000
        );
        break;

      case 2:
        // Test Case 2: Light < 35% with occupancy -> Lights ON
        agent.updateSensors({
          temperature: 24.0,
          occupancy: true,
          ambientLight: 20.0,
          smoke: false
        });
        notifier.showToast(
          'Test Case 2 Applied: Dark Room',
          'Temp: 24°C (< 30°C), Occupied: YES, Light: 20% (< 35%), Smoke: NO -> Result: Lights ACTIVATED, Cooling OFF, Eco INACTIVE.',
          'info',
          5000
        );
        break;

      case 3:
        // Test Case 3: Both conditions met
        agent.updateSensors({
          temperature: 33.5,
          occupancy: true,
          ambientLight: 15.0,
          smoke: false
        });
        notifier.showToast(
          'Test Case 3 Applied: High Temp & Low Light Combo',
          'Temp: 33.5°C (>= 30°C), Occupied: YES, Light: 15% (< 35%), Smoke: NO -> Result: Both Cooling & Lights ACTIVATED simultaneously.',
          'info',
          5000
        );
        break;

      case 4:
        // Test Case 4: Vacant Room -> Energy-Saving Mode, Cooling & Lights OFF
        agent.updateSensors({
          temperature: 35.0,
          occupancy: false,
          ambientLight: 10.0,
          smoke: false
        });
        notifier.showToast(
          'Test Case 4 Applied: Room Empty / Energy-Saving',
          'Temp: 35°C, Occupied: NO (Empty), Light: 10%, Smoke: NO -> Result: Energy-Saving ACTIVE. Cooling and Lights forced OFF despite high heat and darkness.',
          'info',
          6000
        );
        break;

      case 5:
        // Test Case 5: Smoke Detection -> Emergency Override
        agent.updateSensors({
          temperature: 35.0,
          occupancy: false,
          ambientLight: 10.0,
          smoke: true
        });
        notifier.showToast(
          'Test Case 5 Applied: Smoke Emergency Override',
          'Smoke: DETECTED! (Priority 1) -> Result: Emergency warning, repeating siren sounding, browser notification, overriding all other rules.',
          'danger',
          6000
        );
        break;
    }

    renderDashboard(agent.getState());
  }

  els.btnTestCase1.addEventListener('click', () => applyTestCase(1));
  els.btnTestCase2.addEventListener('click', () => applyTestCase(2));
  els.btnTestCase3.addEventListener('click', () => applyTestCase(3));
  els.btnTestCase4.addEventListener('click', () => applyTestCase(4));
  els.btnTestCase5.addEventListener('click', () => applyTestCase(5));

  // =========================================================================
  // 7. AUTOMATED SIMULATION SEQUENCE RUNNER (Requirement 12)
  // Demonstrates all five test cases in succession with visual progress
  // =========================================================================
  const testCaseSequence = [
    {
      num: 1,
      title: 'Test Case 1: Automatic Cooling Activation (Temp >= 30°C)',
      description: 'Simulating hot afternoon (32°C) with occupant present and daylight (55%). Expecting: Cooling ON, Lights OFF.',
      sensors: { temperature: 32.0, occupancy: true, ambientLight: 55.0, smoke: false },
      expectedActuators: { cooling: true, lights: false, energySaving: false, emergencyWarning: false }
    },
    {
      num: 2,
      title: 'Test Case 2: Automatic Smart Lighting (Occupied & Light < 35%)',
      description: 'Simulating evening dimming (20% light) at comfortable 24°C with occupant present. Expecting: Lights ON, Cooling OFF.',
      sensors: { temperature: 24.0, occupancy: true, ambientLight: 20.0, smoke: false },
      expectedActuators: { cooling: false, lights: true, energySaving: false, emergencyWarning: false }
    },
    {
      num: 3,
      title: 'Test Case 3: Combined Comfort Demand (Temp >= 30°C & Light < 35%)',
      description: 'Simulating hot summer night (33.5°C, 15% light) with occupant present. Expecting: Both Cooling and Lights ON.',
      sensors: { temperature: 33.5, occupancy: true, ambientLight: 15.0, smoke: false },
      expectedActuators: { cooling: true, lights: true, energySaving: false, emergencyWarning: false }
    },
    {
      num: 4,
      title: 'Test Case 4: Vacant Room Energy-Saving Priority (Occupancy = OFF)',
      description: 'Simulating occupant leaving the room while 35°C heat and 10% dark remain. Expecting: Energy-Saving ACTIVE, Cooling OFF, Lights OFF.',
      sensors: { temperature: 35.0, occupancy: false, ambientLight: 10.0, smoke: false },
      expectedActuators: { cooling: false, lights: false, energySaving: true, emergencyWarning: false }
    },
    {
      num: 5,
      title: 'Test Case 5: Smoke Detection Highest Priority Override',
      description: 'Simulating smoke alarm triggering. Highest priority safety rule must override all other states immediately. Expecting: Emergency Warning ON, Audible Alarm ON, Browser Notification ON.',
      sensors: { temperature: 35.0, occupancy: false, ambientLight: 10.0, smoke: true },
      expectedActuators: { cooling: false, lights: true, energySaving: false, emergencyWarning: true }
    }
  ];

  function stopSimulationIfRunning() {
    if (simulationRunning) {
      clearTimeout(simulationTimer);
      simulationRunning = false;
      els.btnRunSimulation.textContent = '▶ Run All 5 Test Cases Demo';
      els.btnRunSimulation.classList.remove('btn-running');
      els.simulationProgress.classList.add('hidden');
    }
  }

  function runSimulationSequence() {
    if (simulationRunning) {
      stopSimulationIfRunning();
      notifier.showToast('Simulation Stopped', 'Automated demonstration sequence was paused.', 'info');
      return;
    }

    simulationRunning = true;
    els.btnRunSimulation.textContent = '⏹ Stop Simulation Sequence';
    els.btnRunSimulation.classList.add('btn-running');
    els.simulationProgress.classList.remove('hidden');

    let currentStepIndex = 0;
    const stepDurationMs = 4500; // 4.5 seconds per test case

    function executeStep() {
      if (!simulationRunning) return;

      if (currentStepIndex >= testCaseSequence.length) {
        // Simulation finished!
        simulationRunning = false;
        els.btnRunSimulation.textContent = '▶ Run All 5 Test Cases Demo';
        els.btnRunSimulation.classList.remove('btn-running');
        els.simulationProgressBar.style.width = '100%';
        els.simulationStatusText.textContent = '✓ All 5 Assignment Test Cases Successfully Demonstrated!';
        notifier.showToast('Demo Complete', 'All 5 assignment test cases have been demonstrated successfully.', 'success', 6000);
        
        // Auto reset after demo completes
        simulationTimer = setTimeout(() => {
          if (!simulationRunning) {
            agent.reset();
            renderDashboard(agent.getState());
            els.simulationProgress.classList.add('hidden');
          }
        }, 3500);
        return;
      }

      const step = testCaseSequence[currentStepIndex];
      const progressPercent = Math.round(((currentStepIndex + 1) / testCaseSequence.length) * 100);
      els.simulationProgressBar.style.width = `${progressPercent}%`;
      els.simulationStatusText.innerHTML = `<strong>Step ${step.num} of 5:</strong> ${step.title}`;

      // Apply sensors
      agent.updateSensors(step.sensors);
      renderDashboard(agent.getState());

      notifier.showToast(
        `Simulation [${step.num}/5]: ${step.title}`,
        step.description,
        step.num === 5 ? 'danger' : 'info',
        4000
      );

      currentStepIndex++;
      simulationTimer = setTimeout(executeStep, stepDurationMs);
    }

    // Start with short initial prep
    els.simulationProgressBar.style.width = '5%';
    els.simulationStatusText.textContent = 'Initializing Simulation Sequence...';
    simulationTimer = setTimeout(executeStep, 800);
  }

  els.btnRunSimulation.addEventListener('click', runSimulationSequence);

  // =========================================================================
  // 8. AUTOMATED IN-BROWSER UNIT TESTS RUNNER (Requirement 15)
  // =========================================================================
  async function runBrowserUnitTests() {
    els.testModal.classList.remove('hidden');
    els.testSummaryBanner.innerHTML = '<div class="spinner-border"></div> Executing automated unit test suite...';
    els.testResultsList.innerHTML = '<div class="text-center p-3 text-muted">Running test assertions against agent logic...</div>';

    // Small delay to allow UI to render modal
    await new Promise(r => setTimeout(r, 250));

    const suiteResult = await testSuite.runAllTests();

    // Render Summary Banner
    const isSuccess = suiteResult.failed === 0;
    els.testSummaryBanner.innerHTML = `
      <div class="test-summary-card ${isSuccess ? 'summary-pass' : 'summary-fail'}">
        <div class="summary-header">
          <div class="summary-title">${isSuccess ? '✓ ALL TESTS PASSED' : '⚠ TEST FAILURES DETECTED'}</div>
          <div class="summary-rate">${suiteResult.passed} / ${suiteResult.total} Passed (${suiteResult.passRate}%)</div>
        </div>
        <div class="summary-details">
          <span>Total Assertions: ${suiteResult.total}</span> &bull; 
          <span>Duration: ${suiteResult.durationMs}ms</span> &bull; 
          <span>Target: Decision Logic, Rule Engine, Priority Hierarchy</span>
        </div>
      </div>
    `;

    // Render Test Cases List
    els.testResultsList.innerHTML = suiteResult.tests.map(t => `
      <div class="test-item ${t.passed ? 'test-pass' : 'test-fail'}">
        <div class="test-header">
          <span class="test-id badge ${t.passed ? 'badge-success' : 'badge-danger'}">${t.id}</span>
          <span class="test-name">${escapeHtml(t.title)}</span>
          <span class="test-duration">${t.durationMs}ms</span>
        </div>
        ${t.passed ? 
          '<div class="test-status-msg text-success">✓ Passed: Logic assertions verified</div>' : 
          `<div class="test-status-msg text-danger">✗ Failed: ${escapeHtml(t.error)}</div>`
        }
      </div>
    `).join('');
  }

  els.btnRunAutomatedTests.addEventListener('click', runBrowserUnitTests);
  els.btnCloseTestModal.addEventListener('click', () => els.testModal.classList.add('hidden'));

  // Close modal when clicking on background backdrop
  els.testModal.addEventListener('click', (e) => {
    if (e.target === els.testModal) {
      els.testModal.classList.add('hidden');
    }
  });

  // =========================================================================
  // 9. LOG FILTERING & CLEARING
  // =========================================================================
  els.logFilterButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      els.logFilterButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      activeLogFilter = btn.getAttribute('data-filter');
      renderActionLogs();
    });
  });

  els.btnClearLogs.addEventListener('click', () => {
    agent.clearLogs();
    renderActionLogs();
    notifier.showToast('Log Cleared', 'Action event history log has been cleared.', 'info');
  });

  els.btnExportCsv.addEventListener('click', exportLogsCsv);
  els.btnExportJson.addEventListener('click', exportLogsJson);

  // Keyboard shortcut: ESC clears modals or emergency
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      if (!els.testModal.classList.contains('hidden')) {
        els.testModal.classList.add('hidden');
      }
    }
  });

  // Initial Permission Check and Dashboard Render
  updateNotificationPermissionStatus();
  renderDashboard(agent.getState());
});
