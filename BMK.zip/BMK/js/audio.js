/**
 * Web Audio API Emergency Siren & Sound Synthesizer
 * Generates an authentic repeating audible alarm without any external audio file dependencies.
 */

class SoundSynthesizer {
  constructor() {
    this.audioCtx = null;
    this.sirenInterval = null;
    this.isPlaying = false;
    this.isMuted = false;
    this.volume = 0.5;
    this.oscillator = null;
    this.gainNode = null;
    this.stateListeners = [];
  }

  /**
   * Initialize or resume the Web Audio context (browser requirement on user interaction)
   */
  initContext() {
    if (!this.audioCtx) {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (AudioContextClass) {
        this.audioCtx = new AudioContextClass();
      }
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
  }

  /**
   * Subscribe to sound state changes
   */
  onStateChange(callback) {
    this.stateListeners.push(callback);
  }

  notifyStateChange() {
    this.stateListeners.forEach(cb => cb({
      isPlaying: this.isPlaying,
      isMuted: this.isMuted,
      volume: this.volume
    }));
  }

  /**
   * Start the repeating audible alarm siren
   * Uses alternating European / NFPA two-tone warble (960Hz / 770Hz) with repeating modulation
   */
  startAlarm() {
    if (this.isPlaying) return;
    this.initContext();
    if (!this.audioCtx) return;

    this.isPlaying = true;
    this.notifyStateChange();

    let togglePitch = false;

    // Siren loop function
    const playWarbleCycle = () => {
      if (!this.isPlaying || this.isMuted) return;

      try {
        const now = this.audioCtx.currentTime;
        const osc = this.audioCtx.createOscillator();
        const gain = this.audioCtx.createGain();

        // Dual frequency high-low alarm sweep
        const freq = togglePitch ? 980 : 760;
        togglePitch = !togglePitch;

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(freq, now);
        osc.frequency.exponentialRampToValueAtTime(togglePitch ? 1150 : 680, now + 0.32);

        // Volume envelope: punchy attack, sustained buzz, fast release
        const targetVol = this.isMuted ? 0 : this.volume * 0.35;
        gain.gain.setValueAtTime(0.001, now);
        gain.gain.exponentialRampToValueAtTime(Math.max(0.001, targetVol), now + 0.05);
        gain.gain.setValueAtTime(Math.max(0.001, targetVol), now + 0.28);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.34);

        osc.connect(gain);
        gain.connect(this.audioCtx.destination);

        osc.start(now);
        osc.stop(now + 0.35);
      } catch (err) {
        console.warn('Web Audio synthesis error:', err);
      }
    };

    // Immediate first pulse
    playWarbleCycle();

    // Repeating siren pulse every 380ms
    this.sirenInterval = setInterval(playWarbleCycle, 380);
  }

  /**
   * Stop the repeating audible alarm siren
   */
  stopAlarm() {
    this.isPlaying = false;
    if (this.sirenInterval) {
      clearInterval(this.sirenInterval);
      this.sirenInterval = null;
    }
    this.notifyStateChange();
  }

  /**
   * Toggle mute on/off
   */
  toggleMute() {
    this.isMuted = !this.isMuted;
    this.notifyStateChange();
    return this.isMuted;
  }

  /**
   * Set master volume (0.0 to 1.0)
   */
  setVolume(val) {
    this.volume = Math.max(0, Math.min(1, parseFloat(val)));
    this.notifyStateChange();
  }

  /**
   * Play a brief tactical confirmation beep for UI interactions
   */
  playChime(type = 'click') {
    if (this.isMuted) return;
    this.initContext();
    if (!this.audioCtx) return;

    try {
      const now = this.audioCtx.currentTime;
      const osc = this.audioCtx.createOscillator();
      const gain = this.audioCtx.createGain();

      if (type === 'test') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(880, now);
        osc.frequency.setValueAtTime(1174.66, now + 0.12);
        gain.gain.setValueAtTime(this.volume * 0.25, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
        osc.connect(gain);
        gain.connect(this.audioCtx.destination);
        osc.start(now);
        osc.stop(now + 0.3);
      } else {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(600, now);
        gain.gain.setValueAtTime(this.volume * 0.1, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
        osc.connect(gain);
        gain.connect(this.audioCtx.destination);
        osc.start(now);
        osc.stop(now + 0.08);
      }
    } catch (e) {
      // Audio context might be waiting for user interaction
    }
  }
}

// Export for browser
window.SoundSynthesizer = SoundSynthesizer;
