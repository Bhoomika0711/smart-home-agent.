/**
 * Browser Notification & Visual Alert System
 * Manages HTML5 Notification API with guaranteed in-app visual toast fallback.
 */

class NotificationManager {
  constructor() {
    this.isSupported = 'Notification' in window;
    this.permission = this.isSupported ? Notification.permission : 'unsupported';
    this.lastNotificationTime = 0;
    this.toastContainer = null;
    this.initToastContainer();
  }

  /**
   * Create or locate toast notification container in DOM
   */
  initToastContainer() {
    let container = document.getElementById('toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'toast-container';
      container.className = 'toast-container';
      document.body ? document.body.appendChild(container) : window.addEventListener('DOMContentLoaded', () => document.body.appendChild(container));
    }
    this.toastContainer = container;
  }

  /**
   * Request permission from user for browser system notifications
   */
  async requestPermission() {
    if (!this.isSupported) {
      this.showToast('Browser Notifications Not Supported', 'Your browser does not support system notifications. In-app alerts will be displayed.', 'warning');
      return 'unsupported';
    }

    try {
      const perm = await Notification.requestPermission();
      this.permission = perm;
      if (perm === 'granted') {
        this.showToast('Notifications Enabled', 'System alerts are authorized for emergency notifications.', 'success');
      } else if (perm === 'denied') {
        this.showToast('Notifications Blocked', 'Emergency alerts will still appear as prominent on-screen banners.', 'warning');
      }
      return perm;
    } catch (err) {
      console.warn('Notification permission request error:', err);
      return this.permission;
    }
  }

  /**
   * Trigger an emergency notification across all channels (System Notification + In-App Toast + Banner)
   */
  triggerEmergencyAlert(title = 'EMERGENCY: Smoke Detected!', body = 'Hazard detected! Evacuate immediately. Cooling shutdown. Repeating siren sounding.') {
    const now = Date.now();
    // Throttle duplicate system popups to once every 4 seconds to avoid spamming the OS
    if (now - this.lastNotificationTime > 4000) {
      this.lastNotificationTime = now;

      // 1. Browser Native Notification
      if (this.isSupported && Notification.permission === 'granted') {
        try {
          const notif = new Notification(title, {
            body: body,
            icon: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%23ef4444"><path d="M12 2L1 21h22L12 2zm0 3.99L19.53 19H4.47L12 5.99zM11 10h2v4h-2zm0 6h2v2h-2z"/></svg>',
            requireInteraction: true,
            tag: 'smoke-emergency'
          });
          notif.onclick = () => {
            window.focus();
            notif.close();
          };
        } catch (e) {
          console.warn('Native notification failed, falling back to toast:', e);
        }
      }
    }

    // 2. High-visibility in-app toast banner
    this.showToast(title, body, 'danger', 6000);
  }

  /**
   * Display an in-app animated toast notification
   */
  showToast(title, message, type = 'info', duration = 4000) {
    if (!this.toastContainer) this.initToastContainer();
    if (!this.toastContainer) return;

    const toast = document.createElement('div');
    toast.className = `custom-toast custom-toast-${type}`;
    
    let iconSvg = '';
    if (type === 'danger') {
      iconSvg = '<svg class="toast-icon" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L1 21h22L12 2zm0 3.99L19.53 19H4.47L12 5.99zM11 10h2v4h-2zm0 6h2v2h-2z"/></svg>';
    } else if (type === 'success') {
      iconSvg = '<svg class="toast-icon" viewBox="0 0 24 24" fill="currentColor"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>';
    } else if (type === 'warning') {
      iconSvg = '<svg class="toast-icon" viewBox="0 0 24 24" fill="currentColor"><path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/></svg>';
    } else {
      iconSvg = '<svg class="toast-icon" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>';
    }

    toast.innerHTML = `
      <div class="toast-content">
        <div class="toast-icon-wrapper">${iconSvg}</div>
        <div class="toast-text">
          <div class="toast-title">${title}</div>
          <div class="toast-body">${message}</div>
        </div>
      </div>
      <button class="toast-close" aria-label="Close notification">&times;</button>
    `;

    const closeBtn = toast.querySelector('.toast-close');
    const dismiss = () => {
      toast.classList.add('toast-hiding');
      setTimeout(() => toast.remove(), 300);
    };

    closeBtn.addEventListener('click', dismiss);
    this.toastContainer.appendChild(toast);

    if (duration > 0) {
      setTimeout(dismiss, duration);
    }
  }
}

// Export for browser
window.NotificationManager = NotificationManager;
