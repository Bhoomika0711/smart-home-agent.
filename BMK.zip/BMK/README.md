# Intelligent Agent for Smart Home Automation

An advanced, responsive IoT command center dashboard and rule-based intelligent agent for automated smart home environmental control, energy conservation, and life-safety hazard management.

> ⚠️ **SIMULATION ENVIRONMENT NOTICE**: This project runs entirely in software simulation mode. All sensors (temperature, occupancy, ambient light, and optical smoke) and actuators (cooling HVAC, smart lighting, energy-saving mode, and emergency siren) are simulated. **No physical hardware or IoT microcontrollers are connected.**

---

## 📋 Table of Contents
1. [Project Overview](#project-overview)
2. [Rule-Based Intelligent Agent Architecture](#rule-based-intelligent-agent-architecture)
3. [Features & Capabilities](#features--capabilities)
4. [How to Run the Project Locally](#how-to-run-the-project-locally)
5. [Demonstrating the Five Assignment Test Cases](#demonstrating-the-five-assignment-test-cases)
6. [Master Controls & Simulation Tools](#master-controls--simulation-tools)
7. [Automated Decision Logic Tests](#automated-decision-logic-tests)
8. [File Structure](#file-structure)

---

## 🌟 Project Overview

The **Intelligent Agent for Smart Home Automation** continuously monitors simulated environmental inputs to maintain human comfort, optimize power efficiency, and protect human life through strict priority-based decision rules.

### Key Highlights
- **100% Client-Side & Responsive**: Built with clean, modern HTML5, CSS3 (glassmorphic cyber IoT dashboard), and pure JavaScript.
- **Multi-Sensory Emergency Alarm**: Authentic repeating audible siren synthesized in real time via the **Web Audio API** without external audio file dependencies.
- **Browser Notifications**: Integrated with the standard HTML5 `Notification API` and an automatic in-app banner fallback.
- **Deterministic Rule Engine**: Transparent knowledge base with conflict resolution and human-readable reasoning explanations for every decision.
- **Audit Action Log**: Real-time chronological action log recording every sensor transition, rule fired, and state change with millisecond-precision timestamps. Supports CSV and JSON exports.
- **Dual Test Suites**: In-browser interactive test runner modal (15 tests) + standalone Python test suite (`python test_agent.py`).

---

## 🧠 Rule-Based Intelligent Agent Architecture

The agent evaluates sensor states in a strict, prioritized inference cycle:

```
[Simulated Sensors]
 ├── Temperature Sensor (10°C - 45°C)
 ├── Occupancy Sensor (Present / Vacant)
 ├── Ambient Light Sensor (0% - 100%)
 └── Smoke Sensor (Normal / Hazard)
         │
         ▼
[Intelligent Inference Engine]
 ├── Priority 1: Smoke Emergency Override
 ├── Priority 2: Empty Room Energy Conservation
 ├── Priority 3: Automatic Temperature Cooling
 └── Priority 4: Ambient Light Automation
         │
         ▼
[Actuators & Alert Systems]
 ├── HVAC Cooling System (Compressor ON / OFF / Shutdown)
 ├── Smart Lighting System (ON / OFF / Emergency Strobe)
 ├── Energy-Saving Mode (Eco Active / Inactive)
 └── Emergency Alarm (Repeating Siren + Banner + Browser Notification)
```

### Rule Hierarchy & Priority Table

| Priority | Rule ID | Trigger Condition | Enforced Actuator Actions | Rationale |
| :--- | :--- | :--- | :--- | :--- |
| **Priority 1 (Highest)** | `RULE_1_SMOKE_EMERGENCY` | `smokeDetected == true` | • Emergency Warning **ACTIVE**<br>• Repeating Siren **SOUNDING**<br>• Browser Notification **DISPATCHED**<br>• Cooling System **SHUTDOWN**<br>• Smart Lights **EMERGENCY ON**<br>• Energy-Saving **OVERRIDDEN** | **Life Safety Priority**: In fire emergencies, HVAC is safely halted to prevent smoke distribution through ventilation ducts, while egress paths are illuminated. Overrides all other rules. |
| **Priority 2 (High)** | `RULE_2_ENERGY_SAVING` | `occupancy == false && smoke == false` | • Energy-Saving Mode **ACTIVE**<br>• Cooling System **OFF**<br>• Smart Lights **OFF** | **Energy Conservation**: Eliminates standby power waste when room is vacant, overriding temperature and ambient light demands. |
| **Priority 3 (Medium)** | `RULE_3_COOLING` | `occupancy == true && temperature >= 30.0°C` | • Cooling System **ACTIVE (ON)**<br>• Energy-Saving **INACTIVE** | **Thermal Comfort**: Automatically activates AC compressor when temperature reaches or exceeds 30°C comfort threshold while occupied. |
| **Priority 4 (Normal)** | `RULE_4_LIGHTING` | `occupancy == true && ambientLight < 35.0%` | • Smart Lights **ACTIVE (ON)**<br>• Energy-Saving **INACTIVE** | **Visual Comfort**: Automatically turns lights ON when ambient lighting drops below 35% in an occupied room. |
| **Nominal Standby** | `RULE_STANDBY` | `occupancy == true && temp < 30°C && light >= 35%` | • Cooling System **OFF**<br>• Smart Lights **OFF**<br>• Energy-Saving **INACTIVE** | **Comfort Standby**: Room is occupied with comfortable temperature and adequate natural daylight. |

---

## 🚀 How to Run the Project Locally

The project requires no external frameworks or npm installations. You can launch it in seconds:

### Method 1: Direct Browser Launch (Recommended - Simplest)
1. Open File Explorer and navigate to `c:\BMK` (or your project directory).
2. Double-click on [`index.html`](file:///c:/BMK/index.html) or right-click and choose **Open with Google Chrome**, **Edge**, or **Firefox**.
3. The dashboard loads immediately with full interactive capabilities!

### Method 2: Local Python Web Server
Open PowerShell or Command Prompt in the project folder and run:
```powershell
python -m http.server 8000
```
Then open your browser and navigate to:
```
http://localhost:8000
```

---

## 🎯 Demonstrating the Five Assignment Test Cases

The dashboard includes a dedicated **Assignment Simulation Center** featuring:
1. **"▶ Run All 5 Test Cases Demo"** — An automated walkthrough that runs through all 5 test cases sequentially with progress bars and commentary.
2. **Dedicated 1-Click Test Case Buttons** for instantaneous manual demonstration.

### Test Case 1: Automatic Cooling Activation
- **Trigger**: Click **"Test Case 1"** button (or set Temp = `32°C`, Occupancy = `ON`, Light = `55%`, Smoke = `OFF`).
- **Condition Evaluated**: Temperature has reached $\ge 30^\circ\text{C}$ and occupant is present.
- **Observed Behavior**:
  - Cooling System (HVAC) starts spinning with fast animation; status shows **ACTIVE (ON)** and draws `1600 W`.
  - Smart Lights remain **OFF** (light is $55\% \ge 35\%$).
  - Energy-Saving mode is **INACTIVE**.
  - Action log records: `Cooling System Started (Temp 32°C >= 30°C)`.

### Test Case 2: Dark Room Ambient Lighting
- **Trigger**: Click **"Test Case 2"** button (or set Temp = `24°C`, Occupancy = `ON`, Light = `20%`, Smoke = `OFF`).
- **Condition Evaluated**: Ambient light is $< 35\%$ and occupant is present.
- **Observed Behavior**:
  - Smart Lights illuminate with warm glow; status shows **ACTIVE (ON)** and draws `65 W`.
  - Cooling System remains **OFF** (temp is $24^\circ\text{C} < 30^\circ\text{C}$).
  - Energy-Saving mode is **INACTIVE**.
  - Action log records: `Smart Lights Switched ON (Ambient light 20% < 35%)`.

### Test Case 3: Combined Comfort Demands (High Temp + Low Light)
- **Trigger**: Click **"Test Case 3"** button (or set Temp = `33.5°C`, Occupancy = `ON`, Light = `15%`, Smoke = `OFF`).
- **Condition Evaluated**: Both temperature ($\ge 30^\circ\text{C}$) and light ($< 35\%$) thresholds are crossed simultaneously while occupied.
- **Observed Behavior**:
  - Cooling System is **ACTIVE (ON)**.
  - Smart Lights are **ACTIVE (ON)**.
  - Total power draw reflects both active systems (`~1685 W`).
  - Action log records both cooling and lighting start transitions.

### Test Case 4: Vacant Room Energy-Saving Priority
- **Trigger**: Click **"Test Case 4"** button (or set Occupancy = `OFF`, Temp = `35°C`, Light = `10%`, Smoke = `OFF`).
- **Condition Evaluated**: Occupant leaves the room (`occupancy == false`).
- **Observed Behavior**:
  - **Energy-Saving Mode activates immediately** (green leaf pulsing animation).
  - **Cooling System is forced OFF** (even though temperature is hot at 35°C).
  - **Smart Lights are forced OFF** (even though room is dark at 10%).
  - Power conserved display highlights `~1500 W` saved.
  - Action log records: `Energy-Saving Mode ACTIVATED: Vacant room forced cooling and lights OFF`.

### Test Case 5: Smoke Detection Highest Priority Override
- **Trigger**: Click **"Test Case 5"** button (or click **"🚨 Trigger Smoke Hazard"** / toggle Smoke to `ON`).
- **Condition Evaluated**: Optical smoke detector reports `smoke == true`.
- **Observed Behavior**:
  - Flashing red emergency hazard banner slides in at the top of the screen.
  - Repeating audible alarm siren sounds continuously via Web Audio API.
  - System browser notification popup is triggered.
  - **Overrides all other rules**:
    * Energy-saving mode is overridden.
    * Cooling HVAC system is **immediately shutdown** (`EMERGENCY_SHUTDOWN`) to avoid circulating smoke through air ducts.
    * Emergency evacuation lighting is **illuminated** to safely guide occupants out.
  - Action log records: `Smoke Emergency Triggered: Priority 1 Override Active`.

---

## 🎛️ Master Controls & Simulation Tools

- **Reset System Button**:
  - Restores simulated sensors to baseline safe state: Temperature = `24.0°C`, Occupancy = `ON`, Light = `60%`, Smoke = `OFF`.
  - Silences all alarms and logs the reset event.
- **Emergency Alarm Test Button**:
  - Executes a controlled 6-second multi-sensory emergency alarm drill to test the siren audio, visual beacon, and browser notification. Automatically resets when complete.
- **Audio Siren Controls**:
  - **Mute / Unmute Siren Button**: Allows silencing the audio siren while inspecting dashboard indicators.
  - **Alarm Volume Slider**: Real-time gain control (0% to 100%).
- **Browser Notifications**:
  - **"Enable Notifications 🔔"** button allows testing native desktop notifications through the HTML5 Notification API. If denied, prominent in-app toast alerts guarantee notification visibility.
- **Action Log Manager**:
  - Category filters: `All`, `Emergency`, `Cooling`, `Lighting`, `Energy`, `System`.
  - **Export CSV**: Downloads complete event log as `.csv`.
  - **Export JSON**: Downloads structured JSON log for grading analysis.
  - **Clear Log**: Clears active log table.

---

## 🧪 Automated Decision Logic Tests

The project includes two automated test suites:

### 1. In-Browser Test Suite (Interactive UI)
Click the **"Run Automated Unit Tests"** button in the dashboard header. A modal dialog will execute 15 automated test assertions against the decision logic, verifying:
- Cooling threshold logic and boundaries (`30.0°C` vs `29.9°C`).
- Lighting threshold logic and boundaries (`34.9%` vs `35.0%`).
- Occupancy empty room overrides over high heat and darkness.
- Smoke emergency Priority 1 override across all states.
- HVAC fire safety shutdown.
- State transitions and log generation.

### 2. Standalone Terminal Test Suite (Python)
You can run the Python test suite directly from your terminal:
```powershell
python test_agent.py
```
**Output:**
```
======================================================================
SMART HOME AUTOMATION - AGENT DECISION LOGIC TEST SUITE
======================================================================
test_tc1_high_temperature_cooling ... ok
test_tc1_temp_below_threshold ... ok
test_tc1_temp_boundary_exact_30 ... ok
test_tc2_dark_room_lighting ... ok
test_tc2_light_boundary_35 ... ok
test_tc3_combo_high_temp_and_dark ... ok
test_tc4_empty_room_energy_saving ... ok
test_tc5_smoke_emergency_highest_priority ... ok
test_reset_behavior ... ok

----------------------------------------------------------------------
Ran 9 tests in 0.000s

OK
```

---

## 📁 File Structure

```
c:\BMK\
├── index.html              # Responsive web dashboard structure & accessibility markup
├── css\
│   └── styles.css          # Modern IoT dashboard styling, glassmorphism & animations
├── js\
│   ├── agent.js            # Rule-based intelligent agent core inference engine & state
│   ├── audio.js            # Web Audio API emergency siren synthesizer (no external audio)
│   ├── notification.js     # HTML5 browser notifications & in-app toast fallback
│   ├── dashboard.js        # Controller binding UI, simulation sequence & event handlers
│   └── tests.js            # In-browser unit test suite runner (15 test assertions)
├── test_agent.py           # Standalone Python unit test suite for terminal grading
├── verify.py               # DOM element ID and integrity validation script
└── README.md               # Project documentation and assignment demonstration guide
```

---

## 🏆 Requirements Compliance Summary

| Requirement | Implementation Detail | Status |
| :--- | :--- | :---: |
| 1. Temperature Sensor with adjustable values | Range 10°C–45°C slider, number input, presets (18°C, 24°C, 30°C, 34°C), and color gauge. | ✅ COMPLETE |
| 2. Occupancy Sensor with ON/OFF controls | Toggle switch, quick presets, and visual avatar room occupancy indicator. | ✅ COMPLETE |
| 3. Ambient Light Sensor with adjustable values | Range 0%–100% slider, number input, presets (10%, 25%, 50%, 85%), and lux display. | ✅ COMPLETE |
| 4. Smoke Sensor with ON/OFF controls | Toggle switch, danger styling, and one-click hazard trigger/clear buttons. | ✅ COMPLETE |
| 5. Rule-based intelligent agent | Deterministic inference cycle with conflict resolution and reasoning display. | ✅ COMPLETE |
| 6. Auto cooling at 30°C | Activates cooling HVAC when temperature reaches or exceeds 30.0°C and room is occupied. | ✅ COMPLETE |
| 7. Auto lights when occupied & light < 35% | Illuminates smart lighting when occupant is present and light level is below 35%. | ✅ COMPLETE |
| 8. Empty room energy-saving mode | When room is empty, energy-saving mode activates; cooling and lights forced OFF. | ✅ COMPLETE |
| 9. Smoke emergency warning, siren & notification | Instant emergency top banner, repeating Web Audio API siren, and browser notification. | ✅ COMPLETE |
| 10. Smoke detection highest priority override | Overrides all comfort and energy-saving rules, halts HVAC, turns on egress illumination. | ✅ COMPLETE |
| 11. Action log with timestamps | Millisecond-precision timestamped event log with filtering, CSV and JSON exports. | ✅ COMPLETE |
| 12. Simulation button for all five test cases | Automated sequence runner + 1-click test case buttons for all 5 scenarios. | ✅ COMPLETE |
| 13. Reset and emergency alarm test buttons | Dedicated "Reset System" and "Emergency Alarm Test" drill buttons in header. | ✅ COMPLETE |
| 14. Modern, professional dashboard | Responsive dark glassmorphic IoT command center with animated fans, bulbs, and beacons. | ✅ COMPLETE |
| 15. Automated tests for decision-making logic | Interactive 15-test in-browser test suite modal + Python `unittest` CLI test runner. | ✅ COMPLETE |
| Functional buttons & simulated notice | Every button is fully wired; clear "SIMULATED ENVIRONMENT" banners displayed. | ✅ COMPLETE |

